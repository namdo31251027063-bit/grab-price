"""
app.py - Flask backend cho Grab Price Web App
Chạy: python app.py  →  mở http://localhost:5000
"""

from flask import Flask, request, jsonify, render_template
import numpy as np

# ── Fuzzy System ──────────────────────────────────────────────────────────────
try:
    import skfuzzy as fuzz
    from skfuzzy import control as ctrl

    traffic_ant  = ctrl.Antecedent(np.arange(0, 101, 1), 'traffic')
    peak_ant     = ctrl.Antecedent(np.arange(0, 2, 0.1),  'peak')
    price_factor = ctrl.Consequent(np.arange(1, 4, 0.1),  'price_factor')

    traffic_ant['low']    = fuzz.trimf(traffic_ant.universe, [0,  0,  40])
    traffic_ant['medium'] = fuzz.trimf(traffic_ant.universe, [30, 50, 70])
    traffic_ant['high']   = fuzz.trimf(traffic_ant.universe, [60, 100, 100])

    peak_ant['no']  = fuzz.trimf(peak_ant.universe, [0, 0, 1])
    peak_ant['yes'] = fuzz.trimf(peak_ant.universe, [0, 1, 1])

    price_factor['low']    = fuzz.trimf(price_factor.universe, [1,   1,   1.5])
    price_factor['normal'] = fuzz.trimf(price_factor.universe, [1.3, 2,   2.5])
    price_factor['high']   = fuzz.trimf(price_factor.universe, [2,   3,   3])

    rules = [
        ctrl.Rule(traffic_ant['low'] & peak_ant['no'],   price_factor['low']),
        ctrl.Rule(traffic_ant['medium'],                  price_factor['normal']),
        ctrl.Rule(traffic_ant['high'] | peak_ant['yes'], price_factor['high']),
    ]
    fuzzy_system = ctrl.ControlSystem(rules)
    FUZZY_OK = True
    print("Fuzzy system OK")
except Exception as e:
    FUZZY_OK = False
    print(f"Fuzzy error: {e}")

PRICE_MAP = {"bike": 5_000, "car": 15_000, "van_7": 25_000}

def geocode(addr):
    from geopy.geocoders import Nominatim
    geo = Nominatim(user_agent="grab_web_v1")
    loc = geo.geocode(addr, timeout=8)
    return {"lat": loc.latitude, "lon": loc.longitude} if loc else None

def get_route(c1, c2, vt):
    import requests
    profile = "bike" if vt == "bike" else "car"
    url = (f"https://router.project-osrm.org/route/v1/{profile}/"
           f"{c1['lon']},{c1['lat']};{c2['lon']},{c2['lat']}"
           f"?overview=full&geometries=geojson")
    r = requests.get(url, timeout=10).json()
    if r.get("code") != "Ok": return None
    rt = r["routes"][0]
    return {
        "coords":  [[p[1],p[0]] for p in rt["geometry"]["coordinates"]],
        "dist_km": rt["distance"]/1000,
        "dur_min": rt["duration"]/60,
        "fallback": False,
    }

def straight(c1, c2):
    from geopy.distance import geodesic
    d = geodesic((c1['lat'],c1['lon']),(c2['lat'],c2['lon'])).km
    return {"coords":[[c1['lat'],c1['lon']],[c2['lat'],c2['lon']]],
            "dist_km":d,"dur_min":None,"fallback":True}

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/calculate", methods=["POST"])
def calculate():
    d = request.json
    c1 = geocode(d.get("from",""))
    c2 = geocode(d.get("to",""))
    if not c1 or not c2:
        return jsonify({"error":"Không tìm được địa chỉ. Hãy nhập cụ thể hơn."}), 400

    trf = float(d.get("traffic",50))
    pk  = int(d.get("peak",0))
    vt  = d.get("vehicle","bike")

    if FUZZY_OK:
        try:
            sim = ctrl.ControlSystemSimulation(fuzzy_system)
            sim.input['traffic'] = trf
            sim.input['peak']    = pk
            sim.compute()
            factor = float(sim.output['price_factor'])
        except:
            factor = 1.5 + trf/200
    else:
        factor = 1.5 + trf/200

    route = None
    try: route = get_route(c1, c2, vt)
    except: pass
    if not route: route = straight(c1, c2)

    total = route["dist_km"] * PRICE_MAP.get(vt,5000) * factor
    return jsonify({
        "coord1": c1, "coord2": c2,
        "route":  route["coords"],
        "dist_km": round(route["dist_km"],2),
        "dur_min": round(route["dur_min"]) if route["dur_min"] else None,
        "factor":  round(factor,2),
        "total":   round(total),
        "fallback":route["fallback"],
    })

if __name__ == "__main__":
    print("Server: http://localhost:5000")
    app.run(debug=True, port=5000)
